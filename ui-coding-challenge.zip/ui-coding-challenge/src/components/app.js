import React, { Component } from 'react';
import Name from './settings/name';
import Address from './settings/address';
import FavouriteTeams from './settings/favourite_teams';


class App extends Component {
  constructor(props) {
    super(props);
    }
  render(){
        return (
          <div>
          <header className='header'>Sports Magazine</header>
          <div className='mainDiv'>
          <h2>Sports Magazine Settings</h2>
          <hr />
          <Name />{/* Displays the name portion of the page. The logic is in settings folder*/}
          <hr />{
          <Address />/* Displays the address portion of the page. The logic is in settings folder*/}
          <hr />
          <FavouriteTeams />{/* Displays the team portion of the page. The logic is in settings folder*/}
          </div>
          </div>
         );
       }
     }


export default App;
