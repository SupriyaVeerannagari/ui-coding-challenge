export const editedName = (editedName) => {
  return {
    type: 'NAME',
    payload: editedName
  }
};

export const editedAddress = (editedAddress) => {
  return {
    type: 'ADDRESS',
    payload: editedAddress
  }
};

export const editedFav = (editedFav) => {
  return {
    type: 'FAVOURITES',
    payload: editedFav
  }
};
