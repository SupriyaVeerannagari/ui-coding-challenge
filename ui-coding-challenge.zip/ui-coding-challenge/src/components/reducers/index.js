import { combineReducers } from 'redux';
import { nameReducers } from './nameReducer';

const allReducers = combineReducers({
   default: nameReducers
});
export default allReducers;
