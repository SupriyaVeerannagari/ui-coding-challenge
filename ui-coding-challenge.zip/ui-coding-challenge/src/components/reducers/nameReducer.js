const INITIAL_VALUE =   {
    name: 'Jhonny smith',
    address: '123 Bowl Lane , New York , NY , 10021',
    favouriteTeams: ['None Added']
  }


export const nameReducers = (state= INITIAL_VALUE,  action) => {

  switch (action.type) {
    case 'NAME':
    return Object.assign({}, state, {
      name: action.payload
    })
    case 'ADDRESS':
    return Object.assign({}, state, {
      address: action.payload
    })
    case 'FAVOURITES':
    console.log('act', action.payload)
    return Object.assign({}, state, {
      favouriteTeams: action.payload
    })
  default:
  return state
}
}
