import React, { Component } from 'react';


class ModalWrapper extends Component {
  constructor(props){
    super(props);
    this.state = { showModal: props.display}
    this.onClose = this.onClose.bind(this);
    this.onSubmit = this.onSubmit.bind(this);
}
  componentWillReceiveProps(nextProps){
    this.setState({ showModal: nextProps.display });
}

onClose() {
  this.setState({ showModal: false });
  }
onSubmit() {
  this.props.handlesubmit(true);
  this.onClose();
}

  render() {
    return (
      <div className={this.state.showModal ? 'displayShow modal-overlay' : 'displayNone'}>
        <div className='modal'>
        <header>
          <h1>{this.props.title}</h1>
          <button className='button-close' onClick={this.onClose}></button>
        </header>
        <div>
        {this.props.content}
        </div>
        <div>
            <button className='btns closebtn' onClick={this.onClose}>Close</button>
            <button className='btns savebtn' onClick={this.onSubmit}>Save</button>
        </div>
        </div>
      </div>
    );
  }
}

export default ModalWrapper;
