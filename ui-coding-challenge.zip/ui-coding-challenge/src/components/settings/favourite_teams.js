import React, {Component} from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import ModalWrapper from './modal';
import { editedFav } from '../actions/nameAction'


class Address extends Component {
  constructor(props){
    super(props);
   this.state = {isShow: false,
                  value: this.props.default,
                  fields: [1,2,3]
                 };
    this.handleClick = this.handleClick.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
    this.addFav = this.addFav.bind(this);
    this.addMore = this.addMore.bind(this);
   }

   componentWillReceiveProps(nextProps){
     this.setState({ value: nextProps.default });
   }
  handleClick() {
    this.setState({ isShow: true });

  }
  handleSubmit(param) {
     if(param == true){
       let address = document.querySelectorAll('.fav');
       let arr = []
       for (var i = 0; i < address.length; i++) {
         arr.push(address[i].value)
         this.props.editedFav(arr)
         }
       this.setState({ isShow: false });

     }
   }
   addMore(){
      let currentfield =  this.state.fields;
      currentfield.push(currentfield.length+1);
      this.setState({fields: currentfield});

   }

  addFav(){
    let data = this.state.fields;
    return (
      <div>
    <ul>
    {data.map((i) =>
      <div>
           <label>Team {i}</label><input className='fav' key={i}/>
           </div>
        )}
    </ul>
      <button onClick={this.addMore}>+ Add Another</button>
      </div>
    );

  }
   render() {
     return (
       <div className='divComponents'>
       <span className='width_130'>
       <h3>Add Teams</h3>
       {
        this.state.value.map(function(player) {
           return <li key={player}>{player}</li>
         })
       }
       </span>
       <span>
       <button onClick={this.handleClick} className='btn'>Add Teams</button>
       </span>
       {/* After clicking the button, displays the modal with add teams */}
       <ModalWrapper title={'Add Teams'} content={<this.addFav />} display={this.state.isShow} handlesubmit={this.handleSubmit}/>
      </div>
     );
   }
}


const mapStateToProps = (state) => {
  return{
    default: state.default.favouriteTeams

  };
}
const matchDispatchToProps = (dispatch) => {
     return bindActionCreators({editedFav: editedFav}, dispatch)
}

export default connect(mapStateToProps, matchDispatchToProps) (Address);
