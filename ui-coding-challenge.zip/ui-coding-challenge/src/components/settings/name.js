import React, {Component} from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import ModalWrapper from './modal';
import { editedName } from '../actions/nameAction'


class Name extends Component {
  constructor(props){
    super(props);
    this.state = {isShow: false,
                  value: this.props.default,
                 };
    this.handleClick = this.handleClick.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
   }

   componentWillReceiveProps(nextProps){
     this.setState({ value: nextProps.default });
   }
  handleClick() {
    this.setState({ isShow: true });

  }
  handleSubmit(param) {
     if(param == true){
       let inputName = document.getElementById('inputName').value;
       this.props.editedName(inputName)
       this.setState({ isShow: false });

     }
   }

   render() {
     return (
       <div className='divComponents'>
       <span className='width_130'>
       <h3>Name</h3>
       <p>{this.state.value}</p>
       </span>
       <span>
       <button onClick={this.handleClick} className='btn'>Edit Name</button>
       </span>
       {/* After clicking the button, displays the modal with edit name */}
       <ModalWrapper title={'Edit Name'} content={<NameContent />} display={this.state.isShow} handlesubmit={this.handleSubmit}/>
       </div>


     );
   }
}
export const NameContent = () => {
    return (
      <div>
      <input id='inputName'/>
      </div>
    );
  };

const mapStateToProps = (state) => {
  return{
    default: state.default.name  //just only have one object in the store , so need to itarate.

  };
}
const matchDispatchToProps = (dispatch) => {
     return bindActionCreators({editedName: editedName}, dispatch)
}

export default connect(mapStateToProps, matchDispatchToProps) (Name);
