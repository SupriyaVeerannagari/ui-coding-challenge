import React, {Component} from 'react';
import { bindActionCreators } from 'redux';
import { connect } from 'react-redux';
import ModalWrapper from './modal';
import { editedAddress } from '../actions/nameAction'


class Address extends Component {
  constructor(props){
    super(props);
   this.state = {isShow: false,
                  value: this.props.default,
                 };
    this.handleClick = this.handleClick.bind(this);
    this.handleSubmit = this.handleSubmit.bind(this);
   }

   componentWillReceiveProps(nextProps){
     this.setState({ value: nextProps.default });
   }
  handleClick() {
    this.setState({ isShow: true });

  }
  handleSubmit(param) {
     if(param == true){
       let address = document.getElementById('address').value;
       this.props.editedAddress(address)
       this.setState({ isShow: false });

     }
   }

   render() {
     return (
       <div className='divComponents'>
       <span className='width_130'>
       <h3>Address</h3>
       <p>{this.state.value}</p>
       </span>
       <span>
       <button onClick={this.handleClick} className='btn'>Edit Address</button>
       </span>
       {/* After clicking the button, displays the modal with edit address */}
       <ModalWrapper title={'Edit Address'} content={<NameContent />} display={this.state.isShow} handlesubmit={this.handleSubmit}/>
      </div>
     );
   }
}
export const NameContent = () => {
    return (
      <div>
      <input id='address'/>
      </div>
    );
  };

const mapStateToProps = (state) => {
  return{
    default: state.default.address

  };
}
const matchDispatchToProps = (dispatch) => {
     return bindActionCreators({editedAddress: editedAddress}, dispatch)
}

export default connect(mapStateToProps, matchDispatchToProps) (Address);
